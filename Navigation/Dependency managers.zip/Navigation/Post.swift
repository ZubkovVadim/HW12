
struct Post {
    
    let title: String
    
}
 
