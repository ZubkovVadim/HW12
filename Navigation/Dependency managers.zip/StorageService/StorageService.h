//
//  StorageService.h
//  StorageService
//
//  Created by Vadim on 13.09.2021.
//  Copyright © 2021 Artem Novichkov. All rights reserved.
//

#import <Foundation/Foundation.h>

//! Project version number for StorageService.
FOUNDATION_EXPORT double StorageServiceVersionNumber;

//! Project version string for StorageService.
FOUNDATION_EXPORT const unsigned char StorageServiceVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <StorageService/PublicHeader.h>


